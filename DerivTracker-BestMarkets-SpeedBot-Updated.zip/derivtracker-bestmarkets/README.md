# DerivTracker — BestMarkets

A responsive, light-theme, manual Deriv trading analytics dashboard. It records completed trades entered by the user and calculates profit/loss, win rate, average result, outcome breakdown, and cumulative performance.

## Features

- Light, responsive BestMarkets dashboard
- Manual trade entry: date, market, contract, stake, profit/loss, note
- Net P/L, trade count, win rate, average result
- Wins/losses/breakeven breakdown and cumulative P/L chart
- Search and delete individual trade records
- CSV export
- Reference-inspired SpeedBot panel with Even/Odd pattern display, tick/stake controls, alternation options, Martingale settings and preview-only controls\n- Reference-inspired Bot Builder with trade parameters, purchase conditions, quick strategy and run-preview controls\n- Reference-inspired Bulk Trader setup panel with market, contract, tick, stake and contract-count controls
- Floating AI Market Scanner with multi-market selection and DeepScan ranking from manually recorded trade history (minimum 3 records per market)
- Browser-local storage; no account credentials or Deriv tokens requested
- Static-site deployment to Cloudflare Pages

## Important limitations

- This version is **manual analytics only**. It does not connect to Deriv, read account balances, import live trades, execute trades, or verify entered results.
- SpeedBot, Bot Builder and Bulk Trader are visual setup/preview only. SpeedBot's displayed 20-digit pattern is illustrative, not a live market feed. The digit circles and current-tick area are placeholders until a legitimate live tick data feed is connected. No orders are sent.
- DeepScan ranks only selected markets with at least three manually recorded trades, using the saved win rate and net P/L. It is a historical summary, not a prediction or live market signal.
- Data is stored in the current browser's `localStorage`. It does not sync across devices or browsers. Clearing browser site data can erase records. Export CSV regularly for backup.
- This is an independent tool and is not affiliated with or endorsed by Deriv. Trading involves risk; analytics do not predict future outcomes.

## Project files

```text
derivtracker-bestmarkets/
├── index.html
├── styles.css
├── app.js
├── README.md
└── _headers
```

## Run locally

1. Extract the project ZIP.
2. Open `index.html` in a modern browser.
3. Add a completed trade using the form.
4. Use **Export CSV** to back up your trade history.

For a local web server (optional), run from this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Deploy with GitHub + Cloudflare Pages

### 1. Create a GitHub repository

1. Sign in to GitHub and choose **New repository**.
2. Name it `derivtracker-bestmarkets`.
3. Choose Public or Private, then create the repository.
4. Upload the contents of this folder (not the ZIP file itself) to the repository root.
5. Commit the files to the `main` branch. Suggested commit message: `Initial DerivTracker BestMarkets release`.

### 2. Connect Cloudflare Pages

1. Sign in to the Cloudflare dashboard.
2. Open **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
3. Select GitHub and authorize Cloudflare if prompted.
4. Select `derivtracker-bestmarkets`.
5. Configure the build:
   - Production branch: `main`
   - Framework preset: `None`
   - Build command: leave blank
   - Build output directory: `/` (repository root)
6. Select **Save and Deploy**.
7. When deployment finishes, open the `*.pages.dev` URL shown by Cloudflare.

### 3. Update the website

Edit files in GitHub, commit the changes to `main`, and Cloudflare Pages will deploy the new version automatically.

## Data and privacy

Trade records remain in browser storage on the device and browser where they were entered. This starter project does not send records to a server. Do not enter passwords, Deriv API tokens, or other account secrets.

## Suggested next production upgrades

- Secure user accounts and server-side database for multi-device sync
- CSV import with validation and duplicate detection
- Optional read-only Deriv account integration using an approved OAuth flow
- Admin/user roles and audit logs
- Server-side backups and privacy policy
