(() => {
  const STORAGE_KEY = "bestmarkets_derivtracker_trades_v1";
  const $ = (id) => document.getElementById(id);
  let trades = loadTrades();

  function loadTrades() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(parsed) ? parsed.filter(t => t && typeof t.id === "string") : [];
    } catch { return []; }
  }
  function persist() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(trades)); }
    catch { showMessage("Could not save. Check browser storage settings.", true); }
  }
  function money(value) {
    const n = Number(value) || 0;
    return (n < 0 ? "-$" : "$") + Math.abs(n).toLocaleString("en-US", {minimumFractionDigits:2, maximumFractionDigits:2});
  }
  function dateLabel(value) {
    if (!value) return "—";
    const d = new Date(value + "T12:00:00");
    return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString("en-GB", {day:"2-digit",month:"short",year:"numeric"});
  }
  function outcome(value) { return value > 0 ? "Win" : value < 0 ? "Loss" : "Breakeven"; }
  function showMessage(message, error=false) {
    $("formMessage").textContent = message;
    $("formMessage").style.color = error ? "var(--red)" : "var(--green)";
  }
  function getStats() {
    const count = trades.length;
    const pnl = trades.reduce((s,t) => s + Number(t.result), 0);
    const wins = trades.filter(t => Number(t.result) > 0).length;
    const losses = trades.filter(t => Number(t.result) < 0).length;
    const even = count - wins - losses;
    return {count,pnl,wins,losses,even,rate:count ? wins/count*100 : 0,avg:count ? pnl/count : 0};
  }
  function render() {
    const s = getStats();
    $("netPnl").textContent = money(s.pnl);
    $("netPnl").className = "metric-value " + (s.pnl > 0 ? "positive" : s.pnl < 0 ? "negative" : "");
    $("totalTrades").textContent = s.count;
    $("winRate").textContent = s.rate.toFixed(1) + "%";
    $("winCaption").textContent = `${s.wins} wins · ${s.losses} losses`;
    $("avgResult").textContent = money(s.avg);
    $("avgResult").className = "metric-value " + (s.avg > 0 ? "positive" : s.avg < 0 ? "negative" : "");
    $("pnlCaption").textContent = `${s.wins} winning · ${s.losses} losing · ${s.even} breakeven`;
    $("winsCount").textContent = s.wins;
    $("lossesCount").textContent = s.losses;
    $("breakevenCount").textContent = s.even;
    $("donutRate").textContent = s.rate.toFixed(1) + "%";
    const winDegrees = s.count ? s.wins/s.count*360 : 0;
    const lossDegrees = s.count ? s.losses/s.count*360 : 0;
    $("winDonut").style.background = `conic-gradient(var(--green) 0deg ${winDegrees}deg,var(--red) ${winDegrees}deg ${winDegrees+lossDegrees}deg,#edf0f5 ${winDegrees+lossDegrees}deg 360deg)`;
    renderRows();
    drawChart();
  }
  function renderRows() {
    const q = $("tradeSearch").value.trim().toLowerCase();
    const filtered = [...trades].sort((a,b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id))
      .filter(t => `${t.symbol} ${t.contract} ${t.note}`.toLowerCase().includes(q));
    const body = $("tradeRows");
    if (!filtered.length) {
      body.innerHTML = `<tr><td colspan="7" class="empty-row">${trades.length ? "No matching trades." : "No trades yet. Add your first trade below."}</td></tr>`;
      return;
    }
    body.innerHTML = filtered.map(t => {
      const r = Number(t.result), type = r > 0 ? "win" : r < 0 ? "loss" : "even";
      return `<tr>
        <td>${escapeHTML(dateLabel(t.date))}</td>
        <td class="symbol-cell" title="${escapeHTML(t.note || "")}">${escapeHTML(t.symbol)}</td>
        <td>${escapeHTML(t.contract)}</td>
        <td>${money(t.stake)}</td>
        <td class="result-cell ${r>0?"positive":r<0?"negative":""}">${money(r)}</td>
        <td><span class="outcome ${type}">${outcome(r)}</span></td>
        <td><button class="delete-trade" data-delete="${escapeHTML(t.id)}" aria-label="Delete trade" title="Delete trade">×</button></td>
      </tr>`;
    }).join("");
  }
  function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }
  function drawChart() {
    const canvas = $("performanceChart"), empty = $("chartEmpty");
    const rect = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, rect.width*dpr); canvas.height = Math.max(1, rect.height*dpr);
    const ctx = canvas.getContext("2d"); ctx.scale(dpr,dpr);
    const w=rect.width,h=rect.height,pad={l:48,r:12,t:12,b:27};
    ctx.clearRect(0,0,w,h);
    const range = $("chartRange").value;
    const cutoff = range === "all" ? null : new Date(Date.now()-Number(range)*86400000).toISOString().slice(0,10);
    const ordered = [...trades].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id)).filter(t=>!cutoff||t.date>=cutoff);
    if (!ordered.length) { empty.style.display="grid"; return; }
    empty.style.display="none";
    let total=0; const points=ordered.map(t=>({date:t.date,value:(total+=Number(t.result))}));
    const vals=points.map(p=>p.value); let min=Math.min(0,...vals),max=Math.max(0,...vals);
    if(min===max){min-=1;max+=1;} const extra=(max-min)*.12;min-=extra;max+=extra;
    const x=i=>pad.l+(points.length===1?(w-pad.l-pad.r)/2:i*(w-pad.l-pad.r)/(points.length-1));
    const y=v=>pad.t+(max-v)/(max-min)*(h-pad.t-pad.b);
    ctx.font="10px system-ui";ctx.textAlign="right";ctx.textBaseline="middle";
    for(let i=0;i<5;i++){const v=min+(max-min)*i/4, yy=y(v);ctx.strokeStyle="#edf0f5";ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillStyle="#94a0b1";ctx.fillText((v<0?"-":"")+"$"+Math.abs(v).toFixed(0),pad.l-8,yy);}
    ctx.strokeStyle="#2463eb";ctx.lineWidth=2.5;ctx.lineJoin="round";ctx.lineCap="round";ctx.beginPath();
    points.forEach((p,i)=>i?ctx.lineTo(x(i),y(p.value)):ctx.moveTo(x(i),y(p.value)));ctx.stroke();
    const grad=ctx.createLinearGradient(0,pad.t,0,h-pad.b);grad.addColorStop(0,"rgba(36,99,235,.16)");grad.addColorStop(1,"rgba(36,99,235,0)");
    ctx.lineTo(x(points.length-1),h-pad.b);ctx.lineTo(x(0),h-pad.b);ctx.closePath();ctx.fillStyle=grad;ctx.fill();
    points.forEach((p,i)=>{if(points.length<=20||i===0||i===points.length-1){ctx.beginPath();ctx.arc(x(i),y(p.value),3,0,Math.PI*2);ctx.fillStyle="#2463eb";ctx.fill();}});
    ctx.fillStyle="#94a0b1";ctx.textAlign="left";ctx.textBaseline="top";ctx.fillText(dateLabel(points[0].date),pad.l,h-pad.b+9);
    ctx.textAlign="right";ctx.fillText(dateLabel(points[points.length-1].date),w-pad.r,h-pad.b+9);
  }
  $("tradeForm").addEventListener("submit", e => {
    e.preventDefault();
    const trade = {
      id: (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+Math.random().toString(16).slice(2)),
      date:$("tradeDate").value, symbol:$("symbol").value.trim(), contract:$("contract").value,
      stake:Number($("stake").value), result:Number($("result").value), note:$("note").value.trim()
    };
    if(!trade.date || !trade.symbol || !trade.contract || !Number.isFinite(trade.stake) || trade.stake<=0 || !Number.isFinite(trade.result)){
      showMessage("Please complete all required fields with valid values.",true);return;
    }
    trades.push(trade);persist();render();e.target.reset();$("tradeDate").value=new Date().toISOString().slice(0,10);
    showMessage("Trade record saved on this device.");
  });
  $("tradeRows").addEventListener("click",e=>{
    const btn=e.target.closest("[data-delete]");if(!btn)return;
    const id=btn.dataset.delete;if(!confirm("Delete this trade record?"))return;
    trades=trades.filter(t=>t.id!==id);persist();render();showMessage("Trade record deleted.");
  });
  $("tradeSearch").addEventListener("input",renderRows);
  $("chartRange").addEventListener("change",drawChart);
  $("clearButton").addEventListener("click",()=>{
    if(!trades.length)return;
    if(confirm("Permanently clear all locally saved trade records from this browser?")){trades=[];persist();render();showMessage("All trade records cleared.");}
  });
  $("exportButton").addEventListener("click",()=>{
    const header=["Date","Market","Contract","Stake USD","Profit Loss USD","Note"];
    const rows=trades.map(t=>[t.date,t.symbol,t.contract,t.stake,t.result,t.note]);
    const csv=[header,...rows].map(row=>row.map(v=>`"${String(v??"").replace(/"/g,'""')}"`).join(",")).join("\r\n");
    const blob=new Blob([csv],{type:"text/csv;charset=utf-8"}),url=URL.createObjectURL(blob),a=document.createElement("a");
    a.href=url;a.download="bestmarkets-derivtracker-trades.csv";a.click();URL.revokeObjectURL(url);
  });
  $("menuButton").addEventListener("click",()=>$("sidebar").classList.toggle("open"));
  document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",()=>$("sidebar").classList.remove("open")));

  // Bot Builder: configuration preview only; no orders are submitted.
  function builderSummary() {
    const market=$("builderMarket").value, type=$("builderTradeType").value, contract=$("builderContract").value;
    const duration=$("builderDuration").value, unit=$("builderDurationType").value.toLowerCase();
    const stake=Number($("builderStake").value), count=Number($("builderTradeCount").value);
    if(!Number.isFinite(stake)||stake<0.35||!Number.isInteger(count)||count<1||count>100||!Number.isInteger(Number(duration))||Number(duration)<1){
      $("builderFeedback").textContent="Check the duration, stake (minimum $0.35) and trade count (1–100).";return false;
    }
    $("builderFeedback").textContent=`Preview ready: ${market} · ${type} / ${contract} · ${duration} ${unit} · $${stake.toFixed(2)} stake · ${count} trade(s). No live order has been placed.`;
    return true;
  }
  $("builderRun").addEventListener("click",builderSummary);
  $("quickStrategy").addEventListener("click",()=>{
    $("builderTradeType").value="Digits";$("builderContract").value="Even";
    $("builderDurationType").value="Ticks";$("builderDuration").value="1";
    $("builderStake").value="1";$("builderTradeCount").value="1";builderSummary();
  });
  ["builderMarket","builderTradeType","builderContract","builderContractType","builderInterval","builderDurationType","builderDuration","builderStake","builderPurchase","builderBulk","builderTradeCount","restartBuy","restartLast","builderSpeed"].forEach(id=>{
    $(id).addEventListener("change",()=>{$("builderFeedback").textContent="Settings changed. Select Run preview to review the configuration.";});
  });


  // SpeedBot settings preview only; no broker orders or synthetic live ticks.
  const speedMartingale=$("speedMartingale");
  speedMartingale.addEventListener("change",()=>{$("speedMultiplier").disabled=!speedMartingale.checked;});
  function speedbotPreview(action){
    const ticks=Number($("speedTicks").value),stake=Number($("speedStake").value);
    if(!Number.isInteger(ticks)||ticks<1||!Number.isFinite(stake)||stake<0.35){
      $("speedStatus").textContent="Enter at least 1 tick and a stake of at least $0.35.";return;
    }
    const strategy=$("speedAlternate").checked?"Alternating Even/Odd":"Selected digit strategy";
    const martingale=speedMartingale.checked?` · Martingale ×${$("speedMultiplier").value}`:" · Martingale off";
    $("speedStatus").textContent=`${action} preview ready · ${ticks} tick(s) · $${stake.toFixed(2)} stake · ${strategy}${martingale}. No trade was placed.`;
  }
  $("speedTradeOnce").addEventListener("click",()=>speedbotPreview("Single trade"));
  $("speedStart").addEventListener("click",()=>{
    const btn=$("speedStart");
    if(btn.dataset.running==="true"){btn.dataset.running="false";btn.textContent="START TRADING";$("speedStatus").textContent="Preview stopped. No live trading occurred.";return;}
    speedbotPreview("Start");
    if(!$("speedStatus").textContent.includes("preview ready"))return;
    btn.dataset.running="true";btn.textContent="STOP PREVIEW";
  });
  ["speedTicks","speedStake","speedAlternate","speedOnLoss","speedRecovery","speedMultiplier"].forEach(id=>{
    $(id).addEventListener("change",()=>{$("speedStatus").textContent="Settings updated. Choose Trade Once or Start Trading to preview.";});
  });

  $("year").textContent=new Date().getFullYear();
  $("tradeDate").value=new Date().toISOString().slice(0,10);
  window.addEventListener("resize",drawChart);
  render();
})();